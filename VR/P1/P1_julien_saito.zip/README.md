Julien Saito
45 minutes
I liked having the quick intro to unity and to have already a VR app deployed on the phone.
this README.md file on windows, is not a standard file extension