Julien Saito

5-10 hours

liked creating a quick apartment

did not like aligning objects, but found the hint in the forums
